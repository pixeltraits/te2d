/**
 * Manage Click event
 * @class Mouse
 * For 0.9 version
 */
class Mouse {
	constructor() {
  }
}

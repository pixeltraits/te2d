# README #

Etape 1 -------------------------------------------------- Installation du moteur de jeux ------------------------------------------------------

Télécharger le moteur dans le dossier que vous souhaitez.

Ensuite dans votre document HTML vous devrez appeler les fichier Js suivant:

    <script src="js/te2dJsGameEngine/lib/simpleJsInherit.min.js"></script>    ----------- Celui-ci est intégré au moteur dans le dossier lib.
    <script src="js/te2dJsGameEngine/te2dJsGameEngine-x.x.js"></script>       ----------- x.x doit être le numéro de version du moteur.

Etape 2 -------------------------------------------------- Mise en place de la configuration du jeu ---------------------------------------------

Téléchargez la config de votre jeu dans le dossier de votre choix. Vous devez ensuite dans votre fichier Js appeler la class Game et y parametrer l'url du dossier où se trouve votre config de jeu.

    var myGame = new Game(urldemaconfig);

Ensuite dans votre fichier HTML, créez une balise canvas dont la référence sera renseigné dans le javascript lui meme.

    <canvas id="canvas"></canvas>